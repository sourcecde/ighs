<?php
@session_start() ;
//if (isActionAccessible($guid, $connection2, "/modules/Exam/manageExam.php")==FALSE) {
if (False) {
	//Acess denied
	print "<div class='error'>" ;
		print _("You do not have access to this action.") ;
	print "</div>" ;
}
else{
    
    
    if(isset($_POST["reportcart_add"])){
        
                $sql="UPDATE `table14` SET sub01_et1='".$_POST['sub01_et1']."',sub01_et2='".$_POST['sub01_et2']."',sub01_et3='".$_POST['sub01_et3']."',sub01_et4='".$_POST['sub01_et4']."',
                  sub01_et5='".$_POST['sub01_et5']."',sub01_et6='".$_POST['sub01_et6']."',sub02_et1='".$_POST['sub02_et1']."',sub02_et2='".$_POST['sub02_et2']."',
                    sub02_et3='".$_POST['sub02_et3']."',sub02_et4='".$_POST['sub02_et4']."',sub02_et5='".$_POST['sub02_et5']."',sub02_et6='".$_POST['sub02_et6']."',
                    sub03_et1='".$_POST['sub03_et1']."',sub03_et2='".$_POST['sub03_et2']."',sub03_et3='".$_POST['sub03_et3']."',sub03_et4='".$_POST['sub03_et4']."',
                    sub03_et5='".$_POST['sub03_et5']."',sub03_et6='".$_POST['sub03_et6']."',sub04_et1='".$_POST['sub04_et1']."',sub04_et2='".$_POST['sub04_et2']."',
                    sub04_et3='".$_POST['sub04_et3']."',sub04_et4='".$_POST['sub04_et4']."',sub04_et5='".$_POST['sub04_et5']."',sub04_et6='".$_POST['sub04_et6']."',
                    sub05_et1='".$_POST['sub05_et1']."',sub05_et2='".$_POST['sub05_et2']."',sub05_et3='".$_POST['sub05_et3']."',sub05_et4='".$_POST['sub05_et4']."',
                    sub05_et5='".$_POST['sub05_et5']."',sub05_et6='".$_POST['sub05_et6']."',sub06_et1='".$_POST['sub06_et1']."',sub06_et2='".$_POST['sub06_et2']."',
                    sub06_et3='".$_POST['sub06_et3']."',sub06_et4='".$_POST['sub06_et4']."',sub06_et5='".$_POST['sub06_et5']."',sub06_et6='".$_POST['sub06_et6']."',
                    sub07_et1='".$_POST['sub07_et1']."',sub07_et2='".$_POST['sub07_et2']."',sub07_et3='".$_POST['sub07_et3']."',sub07_et4='".$_POST['sub07_et4']."',
                    sub07_et5='".$_POST['sub07_et5']."',sub07_et6='".$_POST['sub07_et6']."',sub08_et1='".$_POST['sub08_et1']."',sub08_et2='".$_POST['sub08_et2']."',
                    sub08_et3='".$_POST['sub08_et3']."',sub08_et4='".$_POST['sub08_et4']."',sub08_et5='".$_POST['sub08_et5']."',sub08_et6='".$_POST['sub08_et6']."',
                    sub09_et1='".$_POST['sub09_et1']."',sub09_et2='".$_POST['sub09_et2']."',sub09_et3='".$_POST['sub09_et3']."',sub09_et4='".$_POST['sub09_et4']."',
                    sub09_et5='".$_POST['sub09_et5']."',sub09_et6='".$_POST['sub09_et6']."',sub10_et1='".$_POST['sub10_et1']."',sub10_et2='".$_POST['sub10_et2']."',
                    sub10_et3='".$_POST['sub10_et3']."',sub10_et4='".$_POST['sub10_et4']."',sub10_et5='".$_POST['sub10_et5']."',sub10_et6='".$_POST['sub10_et6']."',
                    sub11_et1='".$_POST['sub11_et1']."',sub11_et2='".$_POST['sub11_et2']."',sub11_et3='".$_POST['sub11_et3']."',sub11_et4='".$_POST['sub11_et4']."',
                    sub11_et5='".$_POST['sub11_et5']."',sub11_et6='".$_POST['sub11_et6']."'
                    where _id=".$_POST["report_cart_id"];
            
                    $result1=$connection2->prepare($sql);
	                $result1->execute();
            
                    echo "Submit successfull";
            

    }
    
    
    
    
    
    
    
    
    
    


if(isset($_POST["Go"])){

     $sql1="SELECT gibbonperson.gibbonPersonID,gibbonperson.preferredName,gibbonyeargroup.name as class, gibbonstudentenrolment.rollOrder as roll, gibbonrollgroup.name as section FROM `gibbonperson`
	       LEFT JOIN gibbonstudentenrolment on gibbonstudentenrolment.gibbonPersonID= gibbonperson.gibbonPersonID
	       LEFT JOIN gibbonyeargroup on gibbonstudentenrolment.gibbonYearGroupID= `gibbonyeargroup`.`gibbonYearGroupID`
	       LEFT JOIN gibbonrollgroup on `gibbonrollgroup`.`gibbonYearGroupID`= `gibbonyeargroup`.`gibbonYearGroupID`
	       where gibbonperson.account_number=".$_POST["account_no"];
	       
	$result1=$connection2->prepare($sql1);
	$result1->execute();
	$student_details=$result1->fetch();
	//echo '<pre>ffff';print_r($student_details); 
	
	
	$sql1="SELECT * from table14
	       where table14.personid=".$student_details["gibbonPersonID"];
	       
	$result1=$connection2->prepare($sql1);
	$result1->execute();
	$exam_details=$result1->fetch();
	
    //echo "<pre>";print_r($exam_details);
	
}




}


?>



<html>
    <title></title>
    <head>
         <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
        
    </head>
    
    
    
    <body>
        <center><h4>MARKS ENTRY</h4></center
       
        <div>
            <form action='' method='POST'>
               <!-- <div><label>Account no</label>
                <input type="text" name="account_no" value="">
                <input type="submit" name="Go" value="Go">
                </div>
                -->
                <table>
                    <tr><td>Term</td><td>
                        <select>
                            <option value='1'>1 Term</option>
                            <option value='2'>2 Term</option>
                            <option value='3'>Final Term</option>
                        </select>
                        </td>
                        <td>Account No</td><td><input style='width:50px' type="text" name="account_no" value=""></td><td><input type="submit" name="Go" value="Go"></td>

            
                <td>Name:<input type="text" readonly name="stu_name" value="<?php if(isset($student_details["preferredName"])){ echo $student_details["preferredName"]; }?>" ></td>
                <td>Class:<input type="text" readonly name="stu_class" value="<?php if(isset($student_details["class"])){ echo $student_details["class"]; }?>"></td>
                <td>Section:<input type="text" readonly name="stu_section" value ="<?php if(isset($student_details["section"])){ echo $student_details["section"]; }?>"></td>
                <td>Roll No:<input type="text" readonly name="stu_roll" value="<?php if(isset($student_details["roll"])){ echo $student_details["roll"]; }?>"></td>
            </tr>
        
                    
                    
                </table>
                
            </form>
        </div>
        
     
        <?php if(isset($exam_details)){?>
        
        <form action='' method='POST'>
            <input type="hidden" name="report_cart_id" value="<?php if(isset($exam_details["_id"])){echo $exam_details["_id"];} ?>">
            <table>
               <tr> <td>Subject</td>
               <!-- <td>Graded</td>
                <td>FM</td>
                <td>PM</td>-->
                <td>Grade</td>
                <td>P/Test</td>
                <td>Copy</td>
                <td>Written</td>
                <td>Pract</td>
                <td>Theory</td>
                <td>Proj</td>
               </tr>
               <?php
               $i=1;
               $j=0;
               foreach($exam_details as $ex){ 
                   // echo "<pre>";print_r($exam_details['sub01_name']);die;
                   if($i<10)
                   {
                        $variable1="sub0".$i;
                   }else{
                       $variable1="sub".$i;
                       
                   }
                   //echo $variable1;"<br>";
                   //echo "<pre>";print_r($exam_details[$variable1."_name"]);"<br>";
               ?>
              <tr>
                  <td><?php if(isset($exam_details[$variable1."_name"])){ echo $exam_details[$variable1."_name"];}?></td>
                 <!-- <td><?php if(isset($exam_details[$variable1."_gr"])){ echo $exam_details[$variable1."_gr"];}?></td>
                  <td><?php if(isset($exam_details[$variable1."_fm"]) &&  $exam_details[$variable1."_fm"]!=0){ echo $exam_details[$variable1."_fm"];}?></td>
                  <td><?php if(isset($exam_details[$variable1."_pm"]) && $exam_details[$variable1."_pm"]!=0){ echo $exam_details[$variable1."_pm"];}?></td>
                  -->
                  <td> 
                      <?php if(isset($exam_details[$variable1."_gr"])){ if($exam_details[$variable1."_gr"]=='Y'){?>
                      <select>
                      <option value="A">A</option>
                      <option value="A">B</option>
                      <option value="A">C</option>
                      <option value="A">D</option>
                      </select>
                      <?php }}?>
                      
                    </td>   
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et1" value="" style='width:50px'></span>
                          <span><select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et1_ab"])){echo $exam_details[$variable1."_et1_ab"];}?>"><?php if(isset($exam_details[$variable1."_et1_ab"])){echo $exam_details[$variable1."_et1_ab"];}?></option>
                            </select>
                          </span>
                    </td>
                     
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et2" value="" style='width:50px'></span>
                          <span> <select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et2_ab"])){echo $exam_details[$variable1."_et2_ab"];}?>"><?php if(isset($exam_details[$variable1."_et2_ab"])){echo $exam_details[$variable1."_et2_ab"];}?></option>
                            
                            </select>
                          </span>
                    </td>
                    
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et3" value="" style='width:50px'></span>
                          <span> <select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et3_ab"])){echo $exam_details[$variable1."_et3_ab"];}?>"><?php if(isset($exam_details[$variable1."_et3_ab"])){echo $exam_details[$variable1."_et3_ab"];}?></option>
                            
                            </select>
                          </span>
                    </td>
                    
                    
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et4" value="" style='width:50px'></span>
                          <span> <select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et4_ab"])){echo $exam_details[$variable1."_et4_ab"];}?>"><?php if(isset($exam_details[$variable1."_et4_ab"])){echo $exam_details[$variable1."_et4_ab"];}?></option>
                            
                            </select>
                          </span>
                    </td>
                    
                    
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et5" value="" style='width:50px'></span>
                          <span> <select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et5_ab"])){echo $exam_details[$variable1."_et5_ab"];}?>"><?php if(isset($exam_details[$variable1."_et5_ab"])){echo $exam_details[$variable1."_et5_ab"];}?></option>
                            
                            </select>
                          </span>
                    </td>
                    
                    
                    <td>    
                          <span><input class="num_ab"  id="num_ab" type="text" name="<?php echo $variable1 ?>_et6" value="" style='width:50px'></span>
                          <span> <select class="ab" name="ab" id="ab">
                            <option value="<?php if(isset($exam_details[$variable1."_et6_ab"])){echo $exam_details[$variable1."_et6_ab"];}?>"><?php if(isset($exam_details[$variable1."_et6_ab"])){echo $exam_details[$variable1."_et6_ab"];}?></option>
                            
                            </select>
                          </span>
                    </td>

              </tr> 
               <?php 
               if($i==11){break;}
               
               
               $i++;}  ?>
            </table>
            
            <input type="submit" name="reportcart_add" value="Submit">
        </form>
        
        <?php } ?>
    </body>
</html>


<script>
    $( document ).ready(function() {
    
            $(".ab").on("change",function(){
                
                $("#num_ab").append.attr("readonly");
            });
            
            result="";
            $(".ab").on("click",function(){
                //$('#ab').html('').append(result);
                result+="<option value='Y'>Y</option><option value='N'>N</option>";
                $('.ab').html('').append(result);
            });
    });
    
    
    
</script>




